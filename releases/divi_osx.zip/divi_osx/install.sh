#! /bin/bash

echo "Installing Homebrew, enter Administrator Password..."
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"

echo "Installing Dependancies for Divi...."
brew install autoconf automake berkeley-db@4 libtool boost@1.57 miniupnpc openssl openssl@1.1 pkg-config protobuf qt zmq libevent

/usr/bin/install -c divid /usr/local/bin/divid
/usr/bin/install -c divi-cli /usr/local/bin/divi-cli
/usr/bin/install -c divi-tx /usr/local/bin/divi-tx
echo "Divi binaries installed to /usr/local/bin/"
echo "Divi Install Complete"
