#! /bin/bash

if [[ -d ~/Library/Application\ Support/DIVI ]]
then
	cp ~/Library/Application\ Support/DIVI/divi.conf ./divi.conf.bu
	echo "divi.conf backed up to ./divi.conf.bu"
	tarresult=$(tar -zcvf ./divi-backup.tgz ~/Library/Application\ Support/DIVI/)
	if [ ! $tarresult ] ; 
	then
		echo "Data has been backed up to ././divi-backup.tgz..."
		rm -vrf ~/Library/Application\ Support/DIVI/*
		cp ./divi.conf.bu ~/Library/Application\ Support/DIVI/divi.conf 
		echo "DIVI folder cleaned and divi.conf put back..."
	else
		echo "backup of the data in ~/Library/Application\ Support/DIVI/ folder failed."
		echo "manually delete all file from this folder and put the divi.conf back..."
	fi
else
	echo "~/Library/Application Support/DIVI folder was not found.."
fi
echo "Clean of '~/Library/Application Support/DIVI' has finished..."