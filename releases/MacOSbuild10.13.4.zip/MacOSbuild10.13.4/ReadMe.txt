Expand the zip file and open Terminal to that folder.
Run "chmod +x *.sh" from that folder
Run "./install.sh"

If you want to update the RPC user and password in the divi.conf file do so now.
It's located in: "~/Library/Application\ Support/DIVI"

Run "./start.sh"