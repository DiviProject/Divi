Divi Beta Program
Windows Version 2

Beta Windows Setup Instructions:

1)  Down load the zip file from a link provided for example:  
    https://github.com/Divicoin/Divi/blob/master/releases/divi_win_64.zip
    This may differ slightly depending on the browser.

2)  Unzip the file locally onto your desktop. Windows 10 should support this 
    operation by default and open the folder divi_win_64 and if it contains 
    a folder of the same name open it.  

3)  Open up a command prompt.  this can be the standard 'CMD' or powersheel.  
    for example you might togo the windows search box and enter cmd and the 
    results should almost immediately but command.exe and you can click on 
    that to run it. 

4)  From the command prompt you will need to navigate to the desktop location 
    where the divid.exe and divi-cli.exe files are. 

5)  Outside of the command prompt run divid.exe, accepting any warnings.  It 
    will flash a window and then close.

6)  You need to copy divi.conf from the unziped folder above to a folder that 
    was created behind the scenes.  Navigate to the data directory that was 
    created.  It is in the AppData/Roaming folder and is called DIVI.  This is 
    a hidden system file and you will need to type the path to get into 
    AppData.  (Mine for example is C:\Users\CByrd\AppData\Roaming\DIVI).  
    Replace the divi.conf with the one included in the zip package.

7)  Run divid.exe again.  This time a window should remain open.  You need to 
    keep this open to be able to interact with the underlying system. 

8)  At this point you need to go back to the command prompt and you can now 
    execute Divi-cli commands but to start with you can get your beta address 
    by typing this command into the command prompt: 

    divi-cli getaccountaddress ""

    if you hit return and this command will execute and if you set things up 
    correctly you will get an address back in hex like this: 
    DFrA9TAqLnFWhvCqHmXVKkpw5CJQmZVinK

9)  For the Beta you need to take that address you got form the last step and 
    reach out to the team to get some test 'Divi' send to your beta address.  
    you can check the state of your beta wallet locally be using this command:  

    divi-cli getwalletinfo

    amoung serveral details this will give you the current balance.

10) Next the key or most basic commands you should know about are: 

    divi-cli getblockcount

    this command will let you know where your local system is in terms of how 
    much of the block chain you have and the position.  This is helpful in 
    understanding if you are on the right block or other debugging.  

    divi-cli help 

    this command lets you see a list of all the current commands

    divi-cli stop

    this allows us to nicely stop the divid.exe if something is messed up.  
    you will need to restart it and give it a sec to resync and you can do cli 
    commands again?  
    
    divi-cli senttoaddress "[insert address here]" [insert floating point value]

    This command allows you to send divi to others.  


===========================================================================
== at this point you can be dangerious to your self and others with divi == 
===========================================================================

For a full listing of commands, you can do divi-cli.exe help, or reference the below.

Divi-cli RPC Commands

== Blockchain ==
getbestblockhash
getblock "hash" ( verbose )
getblockchaininfo
getblockcount
getblockhash index
getblockheader "hash" ( verbose )
getchaintips
getdifficulty
getmempoolinfo
getrawmempool ( verbose )
gettxout "txid" n ( includemempool )
gettxoutsetinfo
verifychain ( numblocks )

== Control ==
getinfo
help ( "command" )
stop

== Divi ==
allocatefunds purpose alias amount ( "pay wallet" ( "voting wallet" ) )
createmasternodekey is deprecated!  A masternodekey is no longer necessary for setup.
fundmasternode alias amount TxID masternode ( "pay wallet" ( "voting wallet" ) )
getmasternodecount
getmasternodeoutputs is deprecated!  It has been replaced by fundmasternode for setup.
getmasternodewinners is a work in progress!  Check back soon.
getmasternodestatus
getmasternodewinners is a work in progress!  Check back soon.
Obfuscation, in general, and getpoolinfo, in particular, are deprecated!
listmasternodeconf is deprecated!  It is not necessary for setup.
listmasternodes ( "filter" )
masternode is deprecated!  Use one of the newer, clearer commands.
masternodeconnect "address"
masternodecurrent
mnsync "status|reset"
spork <name> [<value>]
startmasternode is deprecated!  Master nodes now automatically sart themselves

== Generating ==
getgenerate
gethashespersec
setgenerate generate ( genproclimit )

== Getinvalid ==
getinvalid

== Mining ==
getblocktemplate ( "jsonrequestobject" )
getmininginfo
getnetworkhashps ( blocks height )
prioritisetransaction <txid> <priority delta> <fee delta>
reservebalance ( reserve amount )
submitblock "hexdata" ( "jsonparametersobject" )

== Network ==
addnode "node" "add|remove|onetry"
getaddednodeinfo dns ( "node" )
getconnectioncount
getnettotals
getnetworkinfo
getpeerinfo
ping

== Rawtransactions ==
createrawtransaction [{"txid":"id","vout":n},...] {"address":amount,...}
decoderawtransaction "hexstring"
decodescript "hex"
getrawtransaction "txid" ( verbose )
sendrawtransaction "hexstring" ( allowhighfees )
signrawtransaction "hexstring" ( [{"txid":"id","vout":n,"scriptPubKey":"hex","redeemScript":"hex"},...] ["privatekey1",...] sighashtype )

== Util ==
createmultisig nrequired ["key",...]
estimatefee nblocks
estimatepriority nblocks
validateaddress "diviaddress"
verifymessage "diviaddress" "signature" "message"

== Wallet ==
addmultisigaddress nrequired ["key",...] ( "account" )
autocombinerewards true|false ( threshold )
backupwallet "destination"
bip38decrypt "diviaddress"
bip38encrypt "diviaddress"
dumpprivkey "diviaddress"
dumpwallet "filename"
encryptwallet "passphrase"
getaccount "diviaddress"
getaccountaddress "account"
getaddressesbyaccount "account"
getbalance ( "account" minconf includeWatchonly )
getnewaddress ( "account" )
getrawchangeaddress
getreceivedbyaccount "account" ( minconf )
getreceivedbyaddress "diviaddress" ( minconf )
getstakesplitthreshold
getstakingstatus
gettransaction "txid" ( includeWatchonly )
getunconfirmedbalance
getwalletinfo
importaddress "address" ( "label" rescan )
importprivkey "diviprivkey" ( "label" rescan )
importwallet "filename"
keypoolrefill ( newsize )
listaccounts ( minconf includeWatchonly)
listaddressgroupings
listlockunspent
listreceivedbyaccount ( minconf includeempty includeWatchonly)
listreceivedbyaddress ( minconf includeempty includeWatchonly)
listsinceblock ( "blockhash" target-confirmations includeWatchonly)
listtransactions ( "account" count from includeWatchonly)
listunspent ( minconf maxconf  ["address",...] )
lockunspent unlock [{"txid":"txid","vout":n},...]
move "fromaccount" "toaccount" amount ( minconf "comment" )
multisend <command>
sendfrom "fromaccount" "todiviaddress" amount ( minconf "comment" "comment-to" )
sendmany "fromaccount" {"address":amount,...} ( minconf "comment" )
sendtoaddress "diviaddress" amount ( "comment" "comment-to" )
sendtoaddressix "diviaddress" amount ( "comment" "comment-to" )
setaccount "diviaddress" "account"
setstakesplitthreshold value
settxfee amount
signmessage "diviaddress" "message"
