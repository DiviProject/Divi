#! /bin/bash

if [ ! -d ~/Library/Application\ Support/DIVI ]; then
    mkdir -vp ~/Library/Application\ Support/DIVI
fi;

cp ./divi.conf ~/Library/Application\ Support/DIVI/divi.conf

echo "divi.conf file copied to ~/Library/Application Support/DIVI"
